package classify;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class Classification {
	
	/**
	 * @���ż򵥷���
	 */
	private static HashMap<String, ArrayList<String>> dictionary;
	private static HashMap<String, Double> article;
	private static String[][] dicPath;
	private static String testPath;
	private static double[] countClass;
	private static String[] kinds;

	/*
	 * read all dictionary
	 */
	public static void readDics() {
		try {
			for (int i = 0; i < dicPath.length; i++) {
				BufferedReader read = new BufferedReader(new FileReader(
						dicPath[i][0]));
				ArrayList<String> everyDic = new ArrayList<String>();
				String temp = "";
				while ((temp = read.readLine()) != null) {
					everyDic.add(temp);
				}
				dictionary.put(dicPath[i][1], everyDic);
			}
		} catch (Exception e) {
		}
	}

	/*
	 * read a test article
	 */
	public static void readArticle() {
		try {
			BufferedReader read = new BufferedReader(new FileReader(testPath));
			String temp = "";
			while ((temp = read.readLine()) != null) {
				String[] str = temp.split(" ");
				for (String temp1 : str) {
					if (article.containsKey(temp1)) {
						article.put(temp1, article.get(temp1) + 1);
					} else {
						article.put(temp1, 1.0);
					}
				}
			}
		} catch (Exception e) {
		}
	}

	/*
	 * begin to classify
	 */
	public static void classify() {
		for (int i = 0; i < dicPath.length; i++) {
			Iterator<Entry<String, Double>> it = article.entrySet().iterator();
			while (it.hasNext()) {
				Entry<String, Double> entry =it.next();
				String everyWord = (String) entry.getKey();
				ArrayList<String> tempArray=dictionary.get(dicPath[i][1]);
				if (tempArray.contains(everyWord)) {
					countClass[i] += (Double) entry.getValue();
				}
			}
		}
	}

	public Classification(String filePath){
		testPath = filePath;
	}
	/*
	 * sort the times of every kind of news by descending order
	 * save the result in kinds[]
	 */
	public static void sortClass() {
		for (int i = 0; i < countClass.length; i++) {
			for (int j = i; j < countClass.length; j++) {
				if (countClass[j] > countClass[i]) {
					double temp;
					String str;
					temp = countClass[i];
					countClass[i] = countClass[j];
					countClass[j] = temp;
					str = kinds[i];
					kinds[i] = kinds[j];
					kinds[j] = str;
				}
			}
		}
	}

	public static String[] run() {
		dictionary = new HashMap<String, ArrayList<String>>();
		article = new HashMap<String, Double>();
		kinds=new String[4];
		countClass=new double[4];
		dicPath = new String[][] { { "C:/a.txt", "�Ƽ�" }, { "C:/b.txt", "����" },
				{ "C:/c.txt", "����" }, { "C:/d.txt", "����" } };
//		testPath = "C:/e.txt";
		
		for (int i = 0; i < dicPath.length; i++) {
			kinds[i] = dicPath[i][1];
		}
		readDics();
		readArticle();
		classify();
		sortClass();
		return kinds;
	}

	/*
	 * main()
	 */
	public static void main(String[] args) {
		run();
	}

}
