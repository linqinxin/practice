package classify;

public class Test {
public static void main(String args[]){
	Classification test = new Classification("C:/e.txt");
	String[] result=test.run();
}
}
