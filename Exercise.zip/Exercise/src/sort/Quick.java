package sort;

import java.util.Scanner;

public class Quick {
	
    public static void main(String[] args){
        int n;
        Scanner input = new Scanner(System.in);
        n = input.nextInt();
        int[] num=new int[n];
        for(int i=0;i<n;i++){
        	num[i]=input.nextInt();
        }
        quick(num,0,n-1);
        for(int i=0;i<n;i++){
        	System.out.print(num[i]+" ");
        }
    }
    
    public static void quick(int[] num,int low,int high){
    	int mid;
    	if(low<high){
    		mid = partition(num,low,high);
    		quick(num,0,mid-1);
    		quick(num,mid+1,high);
    	}
    }
    
    public static int partition(int[] num,int low,int high){
    	int key;
    	key=num[low];
    	while(low<high){
    		while(num[high]>=key&&low<high)
    			high--;
    		swap(num,low,high);
    		
    		while(num[low]<=key&&low<high)
    			low++;
    		swap(num,low,high);
    	}
    	return low;
    }
    
    public static void swap(int[] num,int low,int high){
    	int temp;
		temp=num[low];
		num[low]=num[high];
		num[high]=temp;
    }
}
