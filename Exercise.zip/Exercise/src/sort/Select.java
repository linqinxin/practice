package sort;

import java.util.Scanner;

public class Select {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int n;
        Scanner input = new Scanner(System.in);
        n = input.nextInt();
        int num[]=new int[n];
        for(int i=0;i<n;i++){
        	num[i]=input.nextInt();
        }
        num=select(num,n);
        for(int i=0;i<n;i++){
        	System.out.print(num[i]+" ");
        }
	}
	
	public static int[] select(int[] allNum,int n){
		int[] num=allNum;
		for(int i=0;i<n;i++){
			int min=i;
			for(int j=i+1;j<num.length;j++){
				if(num[j]<num[i])
					min=j;
			}
			if(min!=i){
				int temp;
				temp=num[i];
				num[i]=num[min];
				num[min]=temp;
			}
		}
		return num;
	}

}
