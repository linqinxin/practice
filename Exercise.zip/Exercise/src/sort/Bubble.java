package sort;

import java.util.Scanner;

public class Bubble {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int n;
        Scanner input = new Scanner(System.in);
        n = input.nextInt();
        int num[]=new int[n];
        for(int i=0;i<n;i++){
        	num[i]=input.nextInt();
        }
        num=bubble(num,n);
        for(int i=0;i<n;i++){
        	System.out.print(num[i]+" ");
        }
	}
	public static int[] bubble(int[] allNum,int n){
		int[] num=allNum;
        for(int i=0;i<n;i++){
        	for(int j=num.length-1;j>i;j--){
        		if(num[j-1]>num[j]){
        			int temp;
        			temp=num[j];
        			num[j]=num[j-1];
        			num[j-1]=temp;
        		}
        	}
        }
		return num;
	}

}
