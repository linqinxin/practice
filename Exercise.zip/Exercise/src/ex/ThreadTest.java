package ex;

public class ThreadTest {

	public static void main(String[] args){
		ThreadCount count = new ThreadCount("l");
		Thread thread = new Thread(count);
		ThreadCount count1 = new ThreadCount("q");
		Thread thread1 = new Thread(count1);
		thread.run();
		thread1.run();
	}
}
