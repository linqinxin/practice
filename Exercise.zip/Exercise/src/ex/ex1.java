package ex;

public class ex1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="<PLACE>";
		 System.out.println(str.replaceAll("<.*>",""));
		 System.out.print(str);
	}

}
