package ex;

import java.util.Scanner;

public class Opposite {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String num;
		Scanner input = new Scanner(System.in);
		num = input.next();
		for(int i=num.length();i>0;i--){
			System.out.print(num.charAt(i-1));
		}
	}

}
