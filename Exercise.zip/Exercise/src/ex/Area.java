package ex;

import java.util.Scanner;

public class Area {
	public static void main(String[] args){
		double area;
		double a,b,c;
		double count;
		Scanner input = new Scanner(System.in);
		a=input.nextDouble();
		b=input.nextDouble();
		c=input.nextDouble();
		count = (a+b+c)/2;
		area=Math.sqrt(count*(count-a)*(count-b)*(count-c));
		System.out.printf("%.2f%n",area);
	}
}
