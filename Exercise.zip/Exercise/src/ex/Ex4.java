package ex;

public class Ex4 {
    public static void main(String[] args){
    	int one;
    	int ten;
    	int hundred;	
    	int sum;
    	
    	for(int i=100;i<1000;i++){
    		hundred=i/100;
    		ten =i/10%10;
    		one=i%100%10;
    		sum = (int) (Math.pow(one, 3)+ Math.pow(ten, 3)+ Math.pow(hundred, 3));
    		if(sum==i){
    			System.out.println(i);
    			break;
    		}
    	}
    }
}
