package ex;

import java.util.Scanner;

public class Ascend {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n;
		int[] num = new int[1000];
		Scanner input = new Scanner(System.in);
		n=10;
		for(int i=0;i<n;i++){
			num[i]=input.nextInt();
		}
		for(int i=0;i<n;i++){
			for(int j=i;j<n;j++){
				if(num[i]>num[j]){
					int temp=0;
					temp=num[i];
					num[i]=num[j];
					num[j]=temp;;
				}
			}
		}
		System.out.println("max="+num[n-1]);
		System.out.println("min="+num[0]);
		
	}

}
