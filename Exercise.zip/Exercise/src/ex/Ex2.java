package ex;

public class Ex2 {
	
    public Ex2(){
    }
	public static void main(String[] args){


	}
}
