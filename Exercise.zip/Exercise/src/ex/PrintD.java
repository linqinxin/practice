package ex;

import java.math.BigDecimal;

public class PrintD {
	public static void main(String[] args){
		//��BigDecimal�����ھ�ȷλ�������
		BigDecimal c=new BigDecimal("2.0");
		BigDecimal d=new BigDecimal("1.2");
		System.out.println(c.subtract(d));
		
		//double �������ȱ��
		double a = 2.0;
		double b= 1.2;
		System.out.printf("%.3f%n",a-b);

		//������
		final long MICROS_PER_DAY = 24L* 60 * 60 * 1000 * 1000;
		final long MILLIS_PER_DAY = 24L * 60 * 60 * 1000;
		System.out.println(MICROS_PER_DAY/MILLIS_PER_DAY);

		//l,L,1,i,I
		System.out.println(12345+54321);
		
	}

}
