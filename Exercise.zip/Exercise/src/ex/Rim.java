package ex;

import java.util.Scanner;

public class Rim {
    public static void main(String[] args){
    	int m,n,sum=0;
    	int[][] num = new int[1000][1000];
    	Scanner input = new Scanner(System.in);
    	m = input.nextInt();
    	n = input.nextInt();
    	for(int i=0;i<m;i++){
    		for(int j=0;j<n;j++){
    			num[i][j]=input.nextInt();
    		}
    	}
    	for(int i=0;i<n;i++){
    		sum=sum+num[0][i]+num[m-1][i];
    	}
    	for(int i=1;i<m-1;i++){
    		sum=sum+num[i][0]+num[i][n-1];
    	}
    	System.out.print(sum);
    }
}
