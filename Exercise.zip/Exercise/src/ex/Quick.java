package ex;

import java.util.Scanner;

public class Quick {

	public static void main(String[] args){
		int n=0;
		Scanner input = new Scanner(System.in);
		n=input.nextInt();
		int[] num = new int[n];
		for(int i=0;i<num.length;i++){
			num[i]=input.nextInt();
		}
		quick(num,0,n-1);
		
		for(int i=0;i<num.length;i++){
			System.out.print(num[i]+" ");
		}
	}
	
	static void quick(int[] num,int low,int high){
		int mid;
		if(low<high){
			mid=sort(num,low,high);
			quick(num,0,mid-1);
			quick(num,mid+1,high);
		}
	}
	
	static int sort(int[] num,int low,int high){
		int temp=num[low];
		while(low<high){
			while(num[high]>=temp&&low<high) high--;
			swap(num,low,high);	
			
			while(num[low]<=temp&&low<high) low++;
			swap(num,low,high);
		}
		return low;
	}
	
	static void swap(int[] num,int low,int high){
		int temp=num[low];
		num[low]=num[high];
		num[high]=temp;
	}
}
