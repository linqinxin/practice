package ex;

import java.util.Scanner;

public class Mark {
	public static void main(String[] args){
    	int n;
    	int num;
    	String name;
    	Scanner input = new Scanner(System.in);
    	n=input.nextInt();
    	student[] stu = new student[n];
    	for(int i=0;i<n;i++){
        	int mark[] = new int[5];
    		num=input.nextInt();
    		name=input.next();
    		for(int j=0;j<mark.length;j++){
    			mark[j]=input.nextInt();
    		}
    		stu[i]=new student(num,name,mark);
    	}
    	for(int i=0;i<n;i++){
    		stu[i].get();
    	}
    }
	static class student{
    	int num;
    	String name;
    	int[] mark;
    	int ave,sum;
    	public student(int num,String name,int[] mark){
    		this.num=num;
    		this.name=name;
    		this.mark=mark;
    	}
    	public void get(){
    		System.out.print(num+" "+name+" ");
    	    for(int i=0;i<mark.length;i++){
    	    	sum+=mark[i];
    	    	System.out.print(mark[i]+" ");
    	    }
    	    System.out.println(sum/mark.length+" ");
    	}
    }
}

