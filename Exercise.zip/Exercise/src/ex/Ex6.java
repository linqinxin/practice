package ex;

import java.util.*;

public class Ex6 {
    public static void main(String[] args){
    	int num;
    	Scanner input = new Scanner("System.in");
    	System.out.println("��������ĳɼ���");
    	num=input.nextInt();
    	int temp=num/10;
    	switch(temp){
    	case 10: System.out.println("A+");
    	break;
    	case 9: System.out.println("A");
    	break;
    	case 8: System.out.println("A-");
    	break;
    	case 7: System.out.println("B+");
    	break;
    	case 6: System.out.println("B");
    	break;
    	default:System.out.println("not pass!");
    	break;
    	}
    }
}
