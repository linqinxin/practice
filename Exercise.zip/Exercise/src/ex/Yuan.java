package ex;

import java.util.Scanner;

public class Yuan {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String str = null;
        char let;
        int count=0;
        Scanner input = new Scanner(System.in);
        str=input.next();
        for(int i=0;i<str.length();i++){
        	let=str.charAt(i);
        	switch(let){
        	case 'a':count++;
        	break;
        	case 'A':count++;
        	break;
        	case 'e':count++;
        	break;
        	case 'E':count++;
        	break;
        	case 'i':count++;
        	break;
        	case 'I':count++;
        	break;
        	case 'o':count++;
        	break;
        	case 'O':count++;
        	break;
        	case 'u':count++;
        	break;
        	case 'U':count++;
        	break;
        	default:
        	break;
        	}
        }
        System.out.println(count);
	}

}
