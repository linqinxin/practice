package ex;

import java.util.Scanner;

public class Kongge {

	public static void main(String[] args) {
		String str,str1="";
		Scanner input = new Scanner(System.in);
		str=input.next();
		for(int i=str.length()-1;i>=0;i--){
			str1+=(String.valueOf(str.charAt(i)));
		}
		if(str1.equals(str))
			System.out.println(str+"�ǻ���");
		else
			System.out.println(str+"���ǻ���");
	}

}
