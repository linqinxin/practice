package ex;

import java.util.Scanner;

public class Ex8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double length,width,hight;
		String b="��1234S5cihid";
		String c="";
		for(int i=b.length()-1;i>=0;i--){
			c+=b.charAt(i);
		}
		System.out.println(c);
		Scanner input = new Scanner(System.in);
		length = input.nextDouble();
		width = input.nextDouble();
		hight = input.nextDouble();
		System.out.println( length+width+hight);

	}

}
