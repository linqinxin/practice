package ex;

import java.util.Scanner;

public class Ex {
    public static void main(String[] args){
    	String str;
    	int big=0,small=0;
    	Scanner input = new Scanner(System.in);
    	str = input.next();
    
    	for(int i=0;i<str.length();i++){
    		if(str.charAt(i)<='Z'&&str.charAt(i)>='A')
    			big++;
    		else if(str.charAt(i)<='z'&&str.charAt(i)>='a')
    			small ++;
    	}
    	System.out.println("��д��ĸ��: "+big +"��\nСд��ĸ��: "+small+"��");
    }
}
