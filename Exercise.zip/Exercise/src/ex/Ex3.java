package ex;

public class Ex3 {
	public static void main(String[] args){
		double sum=1;
		System.out.print("1");
		for(int i=2;i<101;i++){
			sum+=(Math.pow(i, -1)*Math.pow(-1,i+1 ));
			if(i%2==0)
				System.out.print("-1/"+i);
			else
				System.out.print("+1/"+i);
		}
		System.out.print("="+sum);
	}
}
