package ex;

public class ThreadCount implements Runnable {
    private String str;
	
	public ThreadCount(String str){
		this.str=str;
	}
	public void run() {
		for(int i=0;i<5000;i++){
			System.out.print(str);
		}
	}

}
