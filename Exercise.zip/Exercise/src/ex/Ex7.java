package ex;

import java.util.Scanner;

public class Ex7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		String result="";
		Scanner input = new Scanner(System.in);
		str= input.next();
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)>='A'&&str.charAt(i)<'X'|str.charAt(i)>='a'&&str.charAt(i)<'x'){
				String temp=String.valueOf((char)(str.charAt(i)+3));
				result+=temp;
			}
			else
			result+=String.valueOf((char)(str.charAt(i)));
//			System.out.println(str);
		}
		System.out.println(result);

	}

}
