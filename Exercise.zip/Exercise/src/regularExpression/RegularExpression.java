package regularExpression;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class RegularExpression {
	private static String source;
	private static Pattern pattern;
	private static Matcher matcher;
    private static ArrayList<String> weibo;
	
	public static void main(String[] args) throws Exception {
		weibo = new ArrayList<String>();
		String temp = "";
			weibo.add(temp);
		pattern = Pattern.compile("<weibo.*</weibo>");
		matcher = pattern.matcher(source);
		if(matcher.find()){
			System.out.println(matcher.group(0));
			System.out.println();
			System.out.println();
		}
	}
}